package homework.lesson4.drawing;

import princeton.lib.*;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class Fast {

    private final Point[] points;
    private final int numbOfLines;
    private final Line[] lines;
    int numOfPoints;
    List<Line> linesList;

    public Fast(Point[] points) {
        if (points == null) throw new IllegalArgumentException();
        this.points = points;
        Point[] copy = points.clone();
        numOfPoints = points.length;
        linesList = new LinkedList<>();
        drawLines(copy);
        numbOfLines = linesList.size();
        lines = linesList.toArray(new Line[numbOfLines]);

    }

    private void drawLines(Point[] copy) {
        for (Point p : points) {
            Arrays.sort(copy, 0, numOfPoints, p.SLOPE_ORDER);
            int numberOfCollinearPoints = 1, lineId = 1;
            boolean isEq = false;
            for (int i = lineId; i < numOfPoints - 1; i++) {
                if (p.slopeTo(copy[i]) == p.slopeTo(copy[i + 1])) {
                    numberOfCollinearPoints++;
                    if (!isEq) {
                        isEq = true;
                        lineId = i;
                    }
                } else if (isEq) {
                    break;
                }
            }
            if (numberOfCollinearPoints >= 3) {
                Point[] numOfCollinearPoints = new Point[numberOfCollinearPoints + 1];
                numOfCollinearPoints[0] = p;
                System.arraycopy(copy, lineId, numOfCollinearPoints, 1, numberOfCollinearPoints);

                Arrays.sort(numOfCollinearPoints, 0, numberOfCollinearPoints + 1);
                linesList.add(new Line(numOfCollinearPoints[0], numOfCollinearPoints[numberOfCollinearPoints]));

            }
        }
    }


    public Line[] lines() {
        return Arrays.copyOf(lines, numbOfLines);
    }


    public static void main(String[] args) {
        In in = new In("src/homework/lesson4/txt/rs1423.txt");
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();
        Fast collinear = new Fast(points);
        for (Line segment : collinear.lines()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
