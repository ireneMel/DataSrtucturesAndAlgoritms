package homework.lesson4.drawing;

import princeton.lib.*;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;


public class Brute {

    private final int numbOfLines;

    private final Line[] lines;

    public Brute(Point[] points){
        Point[] copy = new Point[points.length];
        System.arraycopy(points, 0, copy, 0, points.length);
        int numOfPoints = points.length;

        List<Line> lines = new LinkedList<>();
        Arrays.sort(points);

        for (int p = 0; p < numOfPoints; p++){
            for (int q = p + 1; q < numOfPoints; q++){
                for (int r = q + 1; r < numOfPoints; r++){
                    for (int s = r + 1; s < numOfPoints; s++){
                        if (points[p].slopeTo(points[q]) == points[p].slopeTo(points[r]) &&
                                points[p].slopeTo(points[r]) == points[p].slopeTo(points[s])){
                            lines.add(new Line(points[p], points[s]));
                        }
                    }
                }
            }
        }

        this.numbOfLines = lines.size();
        this.lines = lines.toArray(new Line[numbOfLines]);

    }

    public Line[] lines(){
        return Arrays.copyOf(this.lines, numbOfLines);
    }

    public static void main(String[] args) {
        In in = new In("src/homework/lesson4/txt/input400.txt");
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        Brute collinear = new Brute(points);
        for (Line segment : collinear.lines()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
